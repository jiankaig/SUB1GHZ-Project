Python_web_App V2 - For running Web Application via python flask 

Prerequisite
1. Python 3 (pip 3)
2. Flask
3. Notepad ++ (Code editing)

#Installing Flask
1. Run "pip3 install flask" on command prompt

#Steps for running the Web application
1. Right click on UDP_Sender.py and open with notepad ++
2. In UPD_Sender.py, modify line 3 ip_Addr to match the ip from CC3200. Save
3. Double click on server.py
4. Look for Running on http:...
5. Copy and paste the ip address on the web browser 
6. Done

